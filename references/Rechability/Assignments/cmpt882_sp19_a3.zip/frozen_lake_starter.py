import gym
import numpy as np

# Create the gym environment
env = gym.make('FrozenLake-v0')

# Initialize Q function

num_episodes = 10000 # Maximum number of episodes

rList = []
for i in range(num_episodes):
	# Start of episode
	rAll = 0

	j = 0
	while j < 99:
		j+=1
		# Throughout the episode...
		#     Choose action based on behaviour policy with respect to Q
		#     Get new state and reward from environment
		#     Update Q function using behaviour and target policies
		
		rAll += r # Keep track of reward for final printing

		if d == True:
			break

	rList.append(rAll)

print("Score over time: " +  str(sum(rList)/num_episodes))
print("Final Q-Table Values")
print(Q)