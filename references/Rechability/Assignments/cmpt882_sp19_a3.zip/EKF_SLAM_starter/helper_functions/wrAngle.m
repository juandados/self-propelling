function theta = wrAngle(theta)
% Wraps an angle between -pi and pi

while theta > pi
  theta = theta - 2*pi;
end

while theta < -pi
  theta = theta + 2*pi;
end

end