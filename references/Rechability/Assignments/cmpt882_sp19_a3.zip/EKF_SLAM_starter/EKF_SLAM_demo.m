function EKF_SLAM_demo()

addpath(genpath('.'))

%% Numerical parameters
dt = 0.1;
T = 100;
tau = 0:dt:T;
numInfty = 1e3; % numerical infinity

%% Environment
Nm = 10; % # landmarks

% Randomly generate landmarks around the unit circle
theta = linspace(0, 2*pi, Nm+1);
theta = theta(1:end-1);
r = 1 + 0.35*rand(size(theta));
m = [r.*cos(theta); r.*sin(theta)];

%% Vehicle parameters
dmax = 0.5; % Sensing radius

% State transition standard deviations
sigma_x = 0.05;
sigma_y = 0.05;
sigma_t = 5/180*pi;

% Measurement standard deviations
sigma_r = 0.01;
sigma_phi = 1/180*pi;

% Vehicle initial state (start somewhere on unit circle)
theta0 = -pi+2*pi*rand;
x = [cos(theta0); sin(theta0); theta0+pi/2];
xs = nan(length(x), length(tau));
xs(:,1) = x;

% Vehicle constant control (go in a circle)
u = [1;1];

%% Augmented state
% Mean
y = [x; nan(2*Nm, 1)];
ys = nan(length(y), length(tau));
ys(:,1) = y;

% Variance
sigmay = numInfty*eye(length(y));
sigmay(1:3, 1:3) = zeros(3);
sigmays = nan(length(y), length(y), length(tau));
sigmays(:,:,1) = sigmay;

%% Initial plot
f = figure;
f.Position = [100 100 800 800];

% True trajectory and map
hx = plot(x(1), x(2), 'k.-');
hold on
hm = plot(m(1,:), m(2,:), 'ro');
grid on
axis square

% Estimated trajectory and map
htraj = plot(ys(1,1), ys(2,1), 'b+-');
hmap = plot(ys(4:2:end,1), ys(5:2:end,1), 'mx');

xlim([-1.5 1.5])
ylim([-1.5 1.5])

legend([hx htraj hmap hm], {"State trajectory", "State estimates", ...
  "Land mark position estimates", "True land mark positions"})

%% Run the experiment for the set time horizon
for i = 2:length(tau)
  % Simulate vehicle for one time step
  x = veh_nState(x, u, dt);
  xs(:,i) = x;
  
  % Make observation
  [z, c] = det_obs(x, m, dmax, sigma_r, sigma_phi);
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Update augmented state using EKF here
  
  
  
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  ys(:,i) = y;                           
  sigmays(:,:,i) = sigmay;
  
  %% Update plot
  % True trajectory
  hx.XData = xs(1,max(1,i-50):i);
  hx.YData = xs(2,max(1,i-50):i);
  
  % Estimated state and map
  htraj.XData = ys(1,max(1,i-50):i);
  htraj.YData = ys(2,max(1,i-50):i);
  hmap.XData = ys(4:2:end,i);
  hmap.YData = ys(5:2:end,i);
  
  drawnow
end
end