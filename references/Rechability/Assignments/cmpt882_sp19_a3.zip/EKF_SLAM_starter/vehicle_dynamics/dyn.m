function xdot = dyn(~, y, u)
% Dynamics of the Dubins Car in ODE form

xdot = zeros(3,1);

v = u(1);
w = u(2);

xdot(1) = v * cos(y(3));
xdot(2) = v * sin(y(3));
xdot(3) = w;

end