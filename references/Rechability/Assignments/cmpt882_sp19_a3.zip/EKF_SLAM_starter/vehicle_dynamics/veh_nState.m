function x = veh_nState(x0, u, dt)
% Integrate ODE dynamics for a duration of dt, under constant control u

[~, x] = ode45(@(t, x) dyn(t,x, u), [0 dt], x0);
x = x(end,:)';

x(3) = wrAngle(x(3));

end