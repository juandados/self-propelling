function veh_nState_test()
N = 12;

f = figure;
f.Position = [100 100 1200 1200];

spc = ceil(sqrt(N));
spr = ceil(N/spc);

dt = 0.1;
sigma_x = 0.01;
sigma_y = 0.01;
sigma_t = 1/180*pi;

for i = 1:N
  % Generate random parameters
  x0 = rand(3,1);
  x0(3) = 2*pi*rand;
  
  v = 0.25 + 1.25*rand;
  w = -1 + 2*rand;

  
  x = veh_nState(x0, [v;w], dt, sigma_x, sigma_y, sigma_t);
  
  % Plot initial and final state
  subplot(spr, spc, i)
  quiver(x0(1), x0(2), cos(x0(3)), sin(x0(3)), 'k')
  hold on
  plot(x0(1), x0(2), 'k.')
  quiver(x(1), x(2), cos(x(3)), sin(x(3)), 'b')
  plot(x(1), x(2), 'b.')
  title(sprintf("dt = %.2f, v = %.2f, w = %.2f, ", dt, v, w));
end
end