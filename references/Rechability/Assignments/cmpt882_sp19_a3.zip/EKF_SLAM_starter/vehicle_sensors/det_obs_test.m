function det_obs_test()

% Environment
Nm = 10;
m = [-2 + 4*rand(1,Nm); -1 + 4*rand(1,Nm)];
dmax = 1;

sigma_r = 0.05;
sigma_phi = 5/180*pi;

f = figure;
f.Position = [100 100 800 600];

% Plot map features (obstacles)
plot(m(1,:), m(2,:), 'ro')
hold on

x = rand(3,1);

% Plot vehicle positoin and heading
quiver(x(1), x(2), cos(x(3)), sin(x(3)), 'k')

z = det_obs(x, m, dmax, sigma_r, sigma_phi);

t = linspace(0, 2*pi, 100);
plot(x(1) + dmax*cos(t), x(2) + dmax*sin(t), 'k:');

Nz = size(z,2);
for i = 1:Nz
  % Plot range and angle measurement
  quiver(x(1), x(2), z(1,i)*cos(z(2,i)+x(3)), z(1,i)*sin(z(2,i)+x(3)), 'b')
end

axis square

end