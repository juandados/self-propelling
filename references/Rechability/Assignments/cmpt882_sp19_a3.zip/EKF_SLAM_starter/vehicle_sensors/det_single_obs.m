function [r, phi] = det_single_obs(x, m)
% x is # states x 1, m is 2x1

r = norm(x(1:2) - m);
phi = atan2(m(2)-x(2), m(1)-x(1)) - x(3);

phi = wrAngle(phi);

end