function [z, c] = det_obs_nn(x, m, dmax)
% Given vehicle state, position of landmarks, sensing range, and sensing noise,
% output no-noise measurements z and correspondences c
% 
% z is 2 x # observations
% c is # observations x 1

Nm = size(m,2);
z = [];
c = [];
for i = 1:Nm
  [r, phi] = det_single_obs(x, m(:,i));
  
  if r <= dmax
    z = [z [r; phi]];
    c = [c; i];
  end
end

end