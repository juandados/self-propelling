function [z, c] = det_obs(x, m, dmax, sigma_r, sigma_phi)
% Given vehicle state, position of landmarks, sensing range, and sensing noise,
% output noisy measurements z and correspondences c
%
% z is 2 x # measurements
% c is 1 x # measurements

[z, c] = det_obs_nn(x, m, dmax);
Nz = size(z,2);

if Nz > 0
  z = z + [sigma_r*randn(1,Nz); sigma_phi*randn(1,Nz)];
end

end